﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim conf As String
        conf = My.Computer.FileSystem.ReadAllText("config.cfg")
        Process.Start(conf)
        End
    End Sub
End Class
